<?php require __DIR__ . "/public/header.html.php"; ?>


<main>
    <div>
<img src="public/assets/img/burger.jpg" alt="">
<p>Discover</p>
<p>OUR GASTRONOMY</p>
<P> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Incidunt, tempora. Modi, vero rem id aliquid molestias iure amet dolorem ipsum animi asperiores perferendis dolore molestiae sint architecto repudiandae veniam possimus.</P>
<a href="">see more...></a>
    </div>
    <p>Tasteful</p>
    <p> RECIPES MADE WITH LOVE</p>
    <P>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos sequi ducimus ut doloremque sed reprehenderit deleniti aspernatur! Aliquam quisquam dignissimos quia adipisci, repudiandae cumque velit tenetur! Numquam cumque consectetur eum?</P>
    <a href=""> see more...></a>
    <img src="public/assets/img/crusted-chicken.jpg" alt="">

    <div>
        <p>menu</p>
        <p>CERTIFIED BIO</p>
        <P>Lorem ipsum dolor sit amet consectetur adipisicing elit. Explicabo repellendus.</P>
    </div>
    <ul>
        <li><a href="">EGGS</a></li>
        <li><a href="">PORC</a></li>
        <li><a href="">CHICKEN</a></li>
        <li><a href="">FISH</a></li>
        <li><a href="">VEGAN</a></li>
    </ul>

    <div>
        <div>
        <img src="public/assets/img/crusted-chicken-square.jpg" alt="">
        <p>Amazing Crusted Chiken</p>
        <p> Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequatur fugiat totam possimus, optio inventore quia officia unde explicabo quas, quasi accusamus id. Odio animi suscipit veritatis, minus ipsa nam nisi.</p>
        <p>$20</p>
        </div>

        <div>
            <p>BoBun Light Odd</p>
        <p> Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequatur fugiat totam possimus, optio inventore quia officia unde explicabo quas, quasi accusamus id. Odio animi suscipit veritatis, minus ipsa nam nisi.</p>
        <p>$20</p>
        <img src="public/assets/img/bobun-light-square.jpg" alt="">


        </div>
        <div>
        <img src="public/assets/img/poisson-square.jpg" alt="">
        <p>Amazing Crusted Chiken</p>
        <p> Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequatur fugiat totam possimus, optio inventore quia officia unde explicabo quas, quasi accusamus id. Odio animi suscipit veritatis, minus ipsa nam nisi.</p>
        <p>$20</p>

        </div>
        <div>
          <p>BoBun Light Odd</p>
        <p> Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequatur fugiat totam possimus, optio inventore quia officia unde explicabo quas, quasi accusamus id. Odio animi suscipit veritatis, minus ipsa nam nisi.</p>
        <p>$20</p>
        <img src="public/assets/img/paella-square.jpg" alt="">

        </div>

    </div>

    <div>
        <p>Chef</p>
        <p>Meet our executive chef, Christian Jacob </p>
       <p> Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellendus dolorem iure numquam dolor facere consectetur doloremque odit! Enim, quaerat veniam eum laudantium ab debitis provident tenetur quod, necessitatibus culpa reiciendis!</p>

    </div>

    <div>

    </div>

    <div>
    <p> RECIPES</p>
    <p> WE SHARE OUR RECIPES WITH YOU</p>
    <P>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sint exercitationem est accusantium alias, harum eaque tempora quo libero fugiat, nihil doloribus nobis eveniet, dolores praesentium architecto qui impedit ipsa. Eius?</P>
    </div>

  <section id="maps">
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d24152.2099885144!2d-73.96868809893893!3d40.827387114418144!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c2f66e2188a29f%3A0xb408afef09e2702e!2sHarlem%2C%20New%20York%2C%20État%20de%20New%20York%2C%20États-Unis!5e0!3m2!1sfr!2sfr!4v1686907089895!5m2!1sfr!2sfr"
          width="100%"
          height="450"
          style="border: 0"
          allowfullscreen=""
          loading="lazy"
          referrerp  ></iframe>
</main>

<?php require __DIR__ . "/public/footer.html.php"; ?>