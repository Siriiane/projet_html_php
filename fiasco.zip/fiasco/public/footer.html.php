<footer><div>
    <p>the Fiasco</p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque omnis corrupti aspernatur dicta aliquam est distinctio laboriosam, velit provident inventore voluptatem nisi architecto debitis quis at. Nemo accusantium quo harum?</p>
</div>
<div>
    <p>Contact Info</p>
    <p> 1234 Altschul, New York, NY 10027-0000 <br>
+19876543210 <br>
contact@thefiasco.com</p>
</div>
<div>
    <p>Openings Hours</p>
    <p>Monday to Friday | 10:00 AM - 11:00 PM</p>
</div>
</footer>