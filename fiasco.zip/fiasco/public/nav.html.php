<ul>
    <li><a href="">about fiasco's</a></li>
    <li><a href="">menu</a></li>
    <li><a href="">recipes</a></li>
    <li><a href="">contact</a></li>
    <li><a href="">make reservation</a></li>
</ul>